/*
 *  version.h
 */

#define SND_UTIL_MAJOR		1
#define SND_UTIL_MINOR		0
#define SND_UTIL_SUBMINOR	22
#define SND_UTIL_VERSION		((SND_UTIL_MAJOR<<16)|\
				 (SND_UTIL_MINOR<<8)|\
				  SND_UTIL_SUBMINOR)
#define SND_UTIL_VERSION_STR	"1.0.22"

