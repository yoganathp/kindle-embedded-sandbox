#ifndef PROC_FILES_H_INCLUDED
#define PROC_FILES_H_INCLUDED

void create_proc_files_list(void);

#endif
