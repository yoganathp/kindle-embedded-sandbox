extern int is_local(char *user);
