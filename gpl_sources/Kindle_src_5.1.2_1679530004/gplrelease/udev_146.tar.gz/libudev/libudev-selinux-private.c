/*
 * libudev - interface to udev device information
 *
 * Copyright (C) 2008 Kay Sievers <kay.sievers@vrfy.org>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdarg.h>
#include <unistd.h>
#include <selinux/selinux.h>

#include "libudev.h"
#include "libudev-private.h"

static int selinux_enabled;
security_context_t selinux_prev_scontext;

void udev_selinux_init(struct udev *udev)
{
	/* record the present security context */
	selinux_enabled = (is_selinux_enabled() > 0);
	info(udev, "selinux=%i\n", selinux_enabled);
	if (!selinux_enabled)
		return;
	matchpathcon_init_prefix(NULL, udev_get_dev_path(udev));
	if (getfscreatecon(&selinux_prev_scontext) < 0) {
		err(udev, "getfscreatecon failed\n");
		selinux_prev_scontext = NULL;
	}
}

void udev_selinux_exit(struct udev *udev)
{
	if (!selinux_enabled)
		return;
	freecon(selinux_prev_scontext);
	selinux_prev_scontext = NULL;
}

void udev_selinux_lsetfilecon(struct udev *udev, const char *file, unsigned int mode)
{
	security_context_t scontext = NULL;

	if (!selinux_enabled)
		return;
	if (matchpathcon(file, mode, &scontext) < 0) {
		err(udev, "matchpathcon(%s) failed\n", file);
		return;
	} 
	if (lsetfilecon(file, scontext) < 0)
		err(udev, "setfilecon %s failed: %m\n", file);
	freecon(scontext);
}

void udev_selinux_setfscreatecon(struct udev *udev, const char *file, unsigned int mode)
{
	security_context_t scontext = NULL;

	if (!selinux_enabled)
		return;
	if (matchpathcon(file, mode, &scontext) < 0) {
		err(udev, "matchpathcon(%s) failed\n", file);
		return;
	}
	if (setfscreatecon(scontext) < 0)
		err(udev, "setfscreatecon %s failed: %m\n", file);
	freecon(scontext);
}

void udev_selinux_resetfscreatecon(struct udev *udev)
{
	if (!selinux_enabled)
		return;
	if (setfscreatecon(selinux_prev_scontext) < 0)
		err(udev, "setfscreatecon failed: %m\n");
}
