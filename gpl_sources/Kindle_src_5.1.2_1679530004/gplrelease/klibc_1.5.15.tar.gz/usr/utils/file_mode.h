#ifndef UTILS_FILE_MODE_H
#define UTILS_FILE_MODE_H

mode_t parse_file_mode(char *arg, mode_t mode, mode_t sumask);

#endif /* UTILS_FILE_MODE_H */
