#include <stdio.h>

int main(void)
{
	fputs("Hello, World!\n", stdout);
	return 0;
}
