#define NAME	 strtotimespec
#define TIMEX	 struct timespec
#define FSEC	 tv_nsec
#define DECIMALS 9
#include "strtotimex.c"
