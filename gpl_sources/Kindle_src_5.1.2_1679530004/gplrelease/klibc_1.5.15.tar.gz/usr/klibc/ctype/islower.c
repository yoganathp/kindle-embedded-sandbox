#include "ctypefunc.h"
CTYPEFUNC(islower)
