#include "ctypefunc.h"
CTYPEFUNC(isspace)
