#include "ctypefunc.h"
CTYPEFUNC(isupper)
