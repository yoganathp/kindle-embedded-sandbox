#include "ctypefunc.h"
CTYPEFUNC(iscntrl)
