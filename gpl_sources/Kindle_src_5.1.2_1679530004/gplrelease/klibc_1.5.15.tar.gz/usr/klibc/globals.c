/*
 * globals.c
 *
 * These have to be defined somewhere...
 */
#include <errno.h>
#include <unistd.h>

int errno;
char **environ;
