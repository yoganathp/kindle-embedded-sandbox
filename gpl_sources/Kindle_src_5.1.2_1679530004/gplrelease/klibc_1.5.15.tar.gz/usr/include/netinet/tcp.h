/*
 * netinet/tcp.h
 */

#ifndef _NETINET_TCP_H
#define _NETINET_TCP_H

#include <endian.h>		/* Include *before* linux/tcp.h */
#include <linux/tcp.h>

#endif				/* _NETINET_TCP_H */
