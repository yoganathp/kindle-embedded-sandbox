/* A module exporting no symbols, and requiring none */
