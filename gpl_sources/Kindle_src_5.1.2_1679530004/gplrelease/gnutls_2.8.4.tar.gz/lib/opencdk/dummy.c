#include <stdio.h>
#include <string.h>

#include "opencdk.h"
#include "main.h"
#include "filters.h"
#include "packet.h"

cdk_error_t
_cdk_proc_packets (cdk_ctx_t hd, cdk_stream_t inp, cdk_stream_t data,
		   const char *output, cdk_stream_t outstream,
		   digest_hd_st * md)
{
  return 0;
}
