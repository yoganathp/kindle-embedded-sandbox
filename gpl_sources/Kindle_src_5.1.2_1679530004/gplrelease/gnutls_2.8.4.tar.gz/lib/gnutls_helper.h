int _gnutls_file_exists (const char *file);
