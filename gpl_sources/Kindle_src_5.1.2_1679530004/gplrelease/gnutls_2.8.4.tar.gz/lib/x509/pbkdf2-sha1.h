int _gnutls_pbkdf2_sha1 (const char *P, size_t Plen,
		const char *S, size_t Slen,
		unsigned int c,
		char *DK, size_t dkLen);
