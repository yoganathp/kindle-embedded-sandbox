/*
 * Copyright 2011 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 */

#include "log.h"
#include <sys/time.h>

unsigned int LLOG_G_LOG_MASK = _LLOG_LEVEL_DEFAULT;

unsigned int gettimems()
{
  struct timeval tv;

  gettimeofday(&tv, 0);
  return ((tv.tv_usec / 1000) + (tv.tv_sec * 1000));
}
