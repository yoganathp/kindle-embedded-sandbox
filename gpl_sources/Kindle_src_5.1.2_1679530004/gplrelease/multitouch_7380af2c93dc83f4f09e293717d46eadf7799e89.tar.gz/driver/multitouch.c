/***************************************************************************
 *
 * Multitouch X driver
 * Copyright (C) 2008 Henrik Rydberg <rydberg@euromail.se>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 **************************************************************************/

#include "gestures.h"
#include "log.h"
#include <pthread.h>

#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 3 
#include <X11/Xatom.h>
#include <xserver-properties.h>
#include <multitouch-properties.h>
#define HAVE_PROPERTIES 1
#endif

#define RANDRSUPPORT 0 
#if RANDRSUPPORT > 0
#include <randrstr.h>
#endif

#define GE_PINCH_ENABLED              1 
#define GE_MOVE_ON_SWIPE              0 

#define GE_ALLOW_ALL                  0
#define GE_ALLOW_PINCH                1
#define GE_ALLOW_NONE                 2

#define MIN_KEYCODE 8
#define KEY_SCREENSHOT                KEY_PRINT+MIN_KEYCODE
#define KEY_SWIPE_TOP                 KEY_PAGEDOWN+MIN_KEYCODE
#define KEY_SWIPE_HOME                KEY_HOME+MIN_KEYCODE

/* button mapping simplified */
#define PROPMAP(m, x, y) m[x] = XIGetKnownProperty(y)

#ifdef HAVE_PROPERTIES
static Atom prop_orientation = 0;
#endif

static int compass[4][4] =
{
  {MT_BUTTON_SWIPE_UP, MT_BUTTON_SWIPE_DOWN, MT_BUTTON_SWIPE_LEFT, MT_BUTTON_SWIPE_RIGHT},
  {MT_BUTTON_SWIPE_DOWN, MT_BUTTON_SWIPE_UP, MT_BUTTON_SWIPE_RIGHT, MT_BUTTON_SWIPE_LEFT},
  {MT_BUTTON_SWIPE_LEFT, MT_BUTTON_SWIPE_RIGHT, MT_BUTTON_SWIPE_DOWN, MT_BUTTON_SWIPE_UP},
  {MT_BUTTON_SWIPE_RIGHT, MT_BUTTON_SWIPE_LEFT, MT_BUTTON_SWIPE_UP, MT_BUTTON_SWIPE_DOWN},
};

XkbRMLVOSet rmlvo;
pthread_mutex_t ge_mutex;

// Protos
static void handle_gestures(LocalDevicePtr local,
    const struct Gestures *gs,
    const struct Capabilities *caps);


static void
SetXkbOption(InputInfoPtr pInfo, char *name, char **option)
{       
    char *s;
  
    if ((s = xf86SetStrOption(pInfo->options, name, NULL))) {
        if (!s[0]) {
            xfree(s);
            *option = NULL;
        } else {
            *option = s;
        }
    }
}

#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 7
static void initAxesLabels(Atom map[2])
{
  memset(map, 0, 2 * sizeof(Atom));
  PROPMAP(map, 0, AXIS_LABEL_PROP_ABS_X);
  PROPMAP(map, 1, AXIS_LABEL_PROP_ABS_Y);
}

static void initButtonLabels(Atom map[DIM_BUTTON])
{
  memset(map, 0, DIM_BUTTON * sizeof(Atom));
  PROPMAP(map, MT_BUTTON_LEFT, BTN_LABEL_PROP_BTN_LEFT);
  PROPMAP(map, MT_BUTTON_MIDDLE, BTN_LABEL_PROP_BTN_MIDDLE);
  /* how to map swipe buttons? */
  PROPMAP(map, MT_BUTTON_SWIPE_UP, BTN_LABEL_PROP_BTN_0);
  PROPMAP(map, MT_BUTTON_SWIPE_DOWN, BTN_LABEL_PROP_BTN_1);
  PROPMAP(map, MT_BUTTON_SWIPE_LEFT, BTN_LABEL_PROP_BTN_2);
  PROPMAP(map, MT_BUTTON_SWIPE_RIGHT, BTN_LABEL_PROP_BTN_3);
  /* how to map scale and rotate? */
  PROPMAP(map, MT_BUTTON_SCALE_DOWN, BTN_LABEL_PROP_BTN_4);
  PROPMAP(map, MT_BUTTON_SCALE_UP, BTN_LABEL_PROP_BTN_5);
  PROPMAP(map, MT_BUTTON_HOLD, BTN_LABEL_PROP_BTN_6);
//  PROPMAP(map, MT_BUTTON_ROTATE_RIGHT, BTN_LABEL_PROP_BTN_7);
//  PROPMAP(map, MT_BUTTON_RIGHT, BTN_LABEL_PROP_BTN_RIGHT);
//  PROPMAP(map, MT_BUTTON_WHEEL_UP, BTN_LABEL_PROP_BTN_WHEEL_UP);
//  PROPMAP(map, MT_BUTTON_WHEEL_DOWN, BTN_LABEL_PROP_BTN_WHEEL_DOWN);
//  PROPMAP(map, MT_BUTTON_HWHEEL_LEFT, BTN_LABEL_PROP_BTN_HWHEEL_LEFT);
//  PROPMAP(map, MT_BUTTON_HWHEEL_RIGHT, BTN_LABEL_PROP_BTN_HWHEEL_RIGHT);
}
#endif

static void pointer_control(DeviceIntPtr dev, PtrCtrl *ctrl)
{
  xf86Msg(X_INFO, "pointer_control\n");
}

static int device_init_valuators(DeviceIntPtr dev, LocalDevicePtr local, int orientation)
{
  struct MTouch *mt = local->private;
  unsigned char btmap[DIM_BUTTON + 1] = {
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9//, 10, 11, 12, 13, 14, 15
  };

#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 7
  Atom axes_labels[2], btn_labels[DIM_BUTTON];
  initAxesLabels(axes_labels);
  initButtonLabels(btn_labels);
#endif

#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) < 3
  InitPointerDeviceStruct((DevicePtr)dev,
        btmap, DIM_BUTTON,
        GetMotionHistory,
        pointer_control,
        GetMotionHistorySize(),
        2);
#elif GET_ABI_MAJOR(ABI_XINPUT_VERSION) < 7
  InitPointerDeviceStruct((DevicePtr)dev,
        btmap, DIM_BUTTON,
        pointer_control,
        GetMotionHistorySize(),
        2);
#elif GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 7
  InitPointerDeviceStruct((DevicePtr)dev,
        btmap, DIM_BUTTON, btn_labels,
        pointer_control,
        GetMotionHistorySize(),
        2, axes_labels);
#else
#error "Unsupported ABI_XINPUT_VERSION"
#endif

	if (orientation <= 1)
	{
		xf86InitValuatorAxisStruct(dev, 0,
#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 7
				axes_labels[0],
#endif
				mt->caps.abs[BIT_POSITION_X].minimum,
				mt->caps.abs[BIT_POSITION_X].maximum,
				10000, 0, 10000);
		xf86InitValuatorDefaults(dev, 0);
		xf86InitValuatorAxisStruct(dev, 1,
#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 7
				axes_labels[1],
#endif
				mt->caps.abs[BIT_POSITION_Y].minimum,
				mt->caps.abs[BIT_POSITION_Y].maximum,
				10000, 0, 10000);
		xf86InitValuatorDefaults(dev, 1);
	}
	else
	{
		xf86InitValuatorAxisStruct(dev, 0,
#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 7
				axes_labels[0],
#endif
				mt->caps.abs[BIT_POSITION_Y].minimum,
				mt->caps.abs[BIT_POSITION_Y].maximum,
				10000, 0, 10000);
		xf86InitValuatorDefaults(dev, 0);
		xf86InitValuatorAxisStruct(dev, 1,
#if GET_ABI_MAJOR(ABI_XINPUT_VERSION) >= 7
				axes_labels[1],
#endif
				mt->caps.abs[BIT_POSITION_X].minimum,
				mt->caps.abs[BIT_POSITION_X].maximum,
				10000, 0, 10000);
		xf86InitValuatorDefaults(dev, 1);
	}
  local->dev->valuator->mode = Absolute;
}

static int device_init_keyboard(DeviceIntPtr dev, LocalDevicePtr local)
{
	InputInfoPtr pInfo = dev->public.devicePrivate;

  /* sorry, no rules change allowed for you */
  xf86ReplaceStrOption(pInfo->options, "xkb_rules", "evdev");
  SetXkbOption(pInfo, "xkb_rules", &rmlvo.rules);
  SetXkbOption(pInfo, "xkb_model", &rmlvo.model);
  if (!rmlvo.model)
    SetXkbOption(pInfo, "XkbModel", &rmlvo.model);
  SetXkbOption(pInfo, "xkb_layout", &rmlvo.layout);
  if (!rmlvo.layout)
    SetXkbOption(pInfo, "XkbLayout", &rmlvo.layout);
  SetXkbOption(pInfo, "xkb_variant", &rmlvo.variant);
  if (!rmlvo.variant)
    SetXkbOption(pInfo, "XkbVariant", &rmlvo.variant);
  SetXkbOption(pInfo, "xkb_options", &rmlvo.options);
  if (!rmlvo.options)
    SetXkbOption(pInfo, "XkbOptions", &rmlvo.options);

  if (!InitKeyboardDeviceStruct(local->dev, &rmlvo, NULL, NULL))
  {
    xf86Msg(X_ERROR, "%s: Keyboard initialization failed. This "
        "could be a missing or incorrect setup of "
        "xkeyboard-config.\n", dev->name);
    return !Success;
  }
  return Success;
}

static int pointer_property(DeviceIntPtr dev,
          Atom property,
          XIPropertyValuePtr prop,
          BOOL checkonly)
{
  xf86Msg(X_INFO, "pointer_property\n");
  return Success;
}

#if RANDRSUPPORT > 0
static void setRotation(struct MTouch *mtouch, Rotation rotation)
{
  int orientation;

  switch(rotation)
  {
    case(RR_Rotate_90 ): orientation = 1; break; // Portrait down
    case(RR_Rotate_0  ): orientation = 3; break; // Landscape right
    case(RR_Rotate_270): orientation = 0; break; // Portrait up 
    case(RR_Rotate_180): orientation = 2; break; // Landscape left
    default: orientation = 0;
  }

  mtouch->orientation = orientation;
}


// This expects framebuffer to start in UD mode
// This converts the touch positions based on the orientation of the screen 
static void convertXY(LocalDevicePtr local, struct MTouch *mtouch, int *x, int *y)
{
  ScrnInfoPtr pScrn = xf86Screens[0];
  Rotation rotation = rrGetScrPriv(pScrn->pScreen) ? RRGetRotation(pScrn->pScreen) : RR_Rotate_270;
  int tmpX = *x;

  if (mtouch->options.randr == FALSE)
    rotation = RR_Rotate_270;
  
  setRotation(mtouch, rotation);
  
  switch(mtouch->orientation)
  {
    case 0: // Portrait UP
      break;
    case 1: // Portrait DOWN  
      *x = mtouch->caps.abs[BIT_POSITION_X].maximum - *x - 1;
      *y = mtouch->caps.abs[BIT_POSITION_Y].maximum - *y - 1;
      break;
    case 2: // Landscape LEFT
      *x = *y;
      tmpX = mtouch->caps.abs[BIT_POSITION_X].maximum - tmpX - 1;
      *y = tmpX;
      break;
    case 3: // Landscape RIGHT
      *y = mtouch->caps.abs[BIT_POSITION_Y].maximum - *y - 1; 
      *x = *y;
      *y = tmpX;
      break;
  }
  
  return;
}


// Sends a motion event that takes into account orientation
static void postConvertedMotionXY(LocalDevicePtr local, int x, int y)
{
  struct MTouch *mtouch = local->private;
  
  convertXY(local, mtouch, &x, &y);
  
  xf86XInputSetScreen(local, 0, x, y);

  xf86PostMotionEvent (local->dev, TRUE, 0, 2, x, y);
}
#else
static void convertXY(LocalDevicePtr local, struct MTouch *mtouch, int *x, int *y)
{
  int tmpX = *x;
 
  switch(mtouch->orientation)
  {
    case 0: // Portrait UP
      break;
    case 1: // Portrait DOWN  
      *x = mtouch->caps.abs[BIT_POSITION_X].maximum - *x - 1;
      *y = mtouch->caps.abs[BIT_POSITION_Y].maximum - *y - 1;
      break;
    case 2: // Landscape LEFT
      *x = *y;
      tmpX = mtouch->caps.abs[BIT_POSITION_X].maximum - tmpX - 1;
      *y = tmpX;
      break;
    case 3: // Landscape RIGHT
      *y = mtouch->caps.abs[BIT_POSITION_Y].maximum - *y - 1; 
      *x = *y;
      *y = tmpX;
      break;
  }
}

// Sends a motion event that takes into account orientation
static void postConvertedMotionXY(LocalDevicePtr local, int x, int y)
{
  struct MTouch *mtouch = local->private;

  convertXY(local, mtouch, &x, &y);

  xf86XInputSetScreen(local, 0, x, y);
  xf86PostMotionEvent (local->dev, TRUE, 0, 2, x, y);
}
#endif // RANDRSUPPORT

#ifdef HAVE_PROPERTIES
// Initialize the Orientation property
static void MTInitProperty(DeviceIntPtr dev)
{
  LocalDevicePtr local = dev->public.devicePrivate;
  struct MTouch *mtouch = local->private;
  int rc;
  
  prop_orientation = MakeAtom(MULTITOUCH_PROP_ORIENTATION, strlen(MULTITOUCH_PROP_ORIENTATION), TRUE);
  
  rc = XIChangeDeviceProperty(dev, prop_orientation, XA_INTEGER, 8,
                              PropModeReplace, 1, &mtouch->orientation, FALSE);
  if (rc != Success)
    return;

  XISetDevicePropertyDeletable(dev, prop_orientation, FALSE);
}

// Orientation property change request 
static int MTSetProperty(DeviceIntPtr dev, Atom atom,
                         XIPropertyValuePtr val, BOOL checkonly)
{
  LocalDevicePtr local = dev->public.devicePrivate;
  struct MTouch *mt = local->private;
  Atom axes_labels[2];
  
  if (atom == prop_orientation)
  {
    if (val->format != 8 || val->type != XA_INTEGER || val->size != 1)
      return BadMatch;
    if (!checkonly)
    {
      int orientation = (Orientation)*((BOOL*)val->data);
      if (orientation >= 0 && orientation < 4)
      {
        if (mt->orientation != orientation)
        {
          device_init_valuators(dev, local, orientation);
          mt->orientation = orientation;
        }
      }
    }
  }
  return Success;
}

static int MTGetProperty(DeviceIntPtr dev, Atom property)
{
  return Success;
}

#endif

static int device_init(DeviceIntPtr dev, LocalDevicePtr local)
{
  struct MTouch *mt = local->private;

  local->fd = xf86OpenSerial(local->options);
  if (local->fd < 0) {
    xf86Msg(X_ERROR, "multitouch: cannot open device\n");
    return !Success;
  }
  if (configure_mtouch(mt, local->fd)) {
    xf86Msg(X_ERROR, "multitouch: cannot configure device\n");
    return !Success;
  }
  xf86CloseSerial(local->fd);

  device_init_valuators(dev, local, 0);
  device_init_keyboard(dev, local);

#ifdef HAVE_PROPERTIES
  MTInitProperty(dev);
  XIRegisterPropertyHandler(dev, MTSetProperty, MTGetProperty, NULL);
#endif
  return Success;
}

static int device_on(LocalDevicePtr local)
{
  struct MTouch *mt = local->private;
  local->fd = xf86OpenSerial(local->options);
  if (local->fd < 0) {
    xf86Msg(X_ERROR, "multitouch: cannot open device\n");
    return !Success;
  }
  if (open_mtouch(mt, local->fd)) {
    xf86Msg(X_ERROR, "multitouch: cannot grab device\n");
    return !Success;
  }
  xf86AddEnabledDevice(local);
  return Success;
}

static int device_off(LocalDevicePtr local)
{
  struct MTouch *mt = local->private;
  xf86RemoveEnabledDevice(local);
  if (close_mtouch(mt, local->fd))
    xf86Msg(X_WARNING, "multitouch: cannot ungrab device\n");
  xf86CloseSerial(local->fd);
  return Success;
}

static int device_close(LocalDevicePtr local)
{
  struct MTouch *mt = local->private;
  if (mt->ge_state.timer != NULL)
    TimerFree(mt->ge_state.timer);
  return Success;
}

static inline void send_button(LocalDevicePtr local, const struct Gestures *gs, int id, int state)
{
  struct MTouch *mt = local->private;
  xf86PostButtonEvent(local->dev, FALSE, id, state, 0, 0);
}

// Tickle the key
static void tickle_key(LocalDevicePtr local, int key)
{ 
  DEBUG_INFO(DEBUG_LLOG, "Sending key event : %d\n", key);
  xf86PostKeyboardEvent(local->dev, key, 1);
  xf86PostKeyboardEvent(local->dev, key, 0);
}

static void tickle_button(LocalDevicePtr local, int id)
{
  DEBUG_INFO(DEBUG_LLOG, "Sending button : %d down\n", id);
  xf86PostButtonEvent(local->dev, FALSE, id, 1, 0, 0);
  DEBUG_INFO(DEBUG_LLOG, "Sending button : %d up\n", id);
  xf86PostButtonEvent(local->dev, FALSE, id, 0, 0, 0);
}

// Timer Function for HOLD event
static CARD32 timerFunc(OsTimerPtr timer, CARD32 now, pointer arg)
{
  LocalDevicePtr local = (LocalDevicePtr)arg;
  struct MTouch* mt = local->private;
  struct Gestures gs;
  int sigState;

  // Avoid any interruptions
  pthread_mutex_lock(&ge_mutex);
  DEBUG_INFO(DEBUG_X_FULL, "Timer holdActive = %u\n", mt->ge_state.holdActive);
  if (mt->ge_state.holdActive == FALSE)
  {
    pthread_mutex_unlock(&ge_mutex);
    return 0;
  }
  DEBUG_INFO(DEBUG_X_LOW, "Hold detected (%ums)\n", gettimems());
  mt->ge_state.holdActive = FALSE;
  mt->ge_state.gestureSent = GE_ALLOW_NONE;
  tickle_button(local, MT_BUTTON_HOLD+1);
  pthread_mutex_unlock(&ge_mutex);
  return 0;
}

/* Returns 1 if something happened. Returns 0 otherwize */
static int  button_scroll(LocalDevicePtr local,
        int btdec, int btinc,
        float *scroll, float step,
        int delta)
{
  struct MTouch *mt = local->private;
  int    ret = GE_ALLOW_ALL;
  
  *scroll += (float)delta;
  if (*scroll >= step) {
    /* Send the button event to where the touch originialy started */
#if GE_MOVE_ON_SWIPE == 1
    // Experimenting not jumping the cursor on swipe event. Might have to revert
    xf86PostMotionEvent(local->dev, 1, 0, 2, mt->mem.xdown, mt->mem.ydown);
#endif
    tickle_button(local, btinc);
    *scroll = 0;
    ret = GE_ALLOW_NONE;
  }
  if (*scroll <= -step) {
    /* Send the button to event to where the touch originialy started */
#if GE_MOVE_ON_SWIPE == 1
    // Experimenting not jumping the cursor on swipe event. Might have to revert
    xf86PostMotionEvent(local->dev, 1, 0, 2, mt->mem.xdown, mt->mem.ydown);
#endif
    tickle_button(local, btdec);
    *scroll = 0;
    ret = GE_ALLOW_NONE;
  }
  return ret;
}

/* Returns 1 if something happened. Returns 0 otherwize */
static int  button_scale(LocalDevicePtr local,
    GestureState *gstate,    
    int btdec, int btinc,
    float *scroll, float step,
    float new_distance)
{
  struct MTouch *mt = local->private;
  int ret = gstate->gestureSent;

  DEBUG_INFO(DEBUG_X_FULL, "Dist : %f __ new_dist : %f __ step : %f\n", *scroll, new_distance, step);
  while (new_distance < (*scroll - step)) {
    /* Send the button to event to where the touch originialy started */
    tickle_button(local, btdec);
    *scroll -= step;
    ret = GE_ALLOW_PINCH;
  }
  while (new_distance > (*scroll + step)) {
    /* Send the button to event to where the touch originialy started */
    tickle_button(local, btinc);
    *scroll += step;
    ret = GE_ALLOW_PINCH;
  }
  return ret;
}

static void clear_gesture_state(LocalDevicePtr local,
                                const struct Gestures *gs,
                                GestureState *gstate,
                                int nFingers)
{ 
  DEBUG_INFO(DEBUG_X_FULL, "Fingers detected : %d\n", nFingers);
  /* Send one gesture until finger released */
  if (!gs->same_fingers || !nFingers)
  {
    gstate->vscroll = 0;
    gstate->hscroll = 0;
    gstate->vswipe = 0;
    gstate->hswipe = 0;
    gstate->holdActive = FALSE;
    DEBUG_INFO(DEBUG_X_FULL, "Clear holdActive : %d\n", gstate->holdActive);
#if GE_PINCH_ENABLED == 1
    /* Clear scale state */
    gstate->distance = 0;
#endif
  }

  if(!nFingers)
    gstate->gestureSent = GE_ALLOW_ALL;
}

/* If the fingers are release too quickly the else statement sends the events */
/* from lower to higher. We want to make sure button 2 is released first      */
/* so that the toolkits can synthesize a click event on a very quick tap.     */
/* If button 2 was down make sure we send the events in backwards order       */
static void handle_button_events(LocalDevicePtr local,
                                 const struct Gestures *gs,
                                 GestureState *gstate,
                                 int nFingers)
{
  struct MTouch *mt = local->private;
  int i = 0;

  
  /* Have to handle these cases explicitely to reposition the cursor */
  if (nFingers == 0 && gstate->nPrevFingers >= 2)
  {
    send_button(local, gs, MT_BUTTON_MIDDLE+1, 0);
    send_button(local, gs, MT_BUTTON_LEFT+1, 0);
  }
  else if (nFingers == 1 && gstate->nPrevFingers >= 2)
  {
    send_button(local, gs, MT_BUTTON_MIDDLE+1, 0);
    postConvertedMotionXY(local, gs->x, gs->y);
  }
  else
  {
    if (nFingers > 0)
    {
      if (mt->options.screenshot && GETBIT(gs->type, GS_SCREENSHOT) && gstate->gestureSent < GE_ALLOW_PINCH)
      {
        gstate->gestureSent = GE_ALLOW_NONE;
        tickle_key(local, KEY_SCREENSHOT);
        return;
      }

      /* Number of fingers changed. Reposition the cursor */
      if (nFingers != gstate->nPrevFingers)
      {
        if (nFingers == 1)
        {
          DEBUG_INFO(DEBUG_X_LOW, "Touch down X: %d Y: %d (%d,%d) (%ums)\n", mt->mem.xdown, mt->mem.ydown, GE_CONVERT_X(mt->mem.xdown), GE_CONVERT_Y(mt->mem.ydown), gettimems());
          if (mt->options.debug)
          {
            DEBUG_INFO(DEBUG_LLOG, "Touch down X: %d Y: %d (%d,%d) (%ums)\n", mt->mem.xdown, mt->mem.ydown, GE_CONVERT_X(mt->mem.xdown), GE_CONVERT_Y(mt->mem.ydown), gettimems());
          }
          // Send the position
          postConvertedMotionXY(local, gs->x, gs->y);
        }
        
        if (nFingers > 1 && gstate->gestureSent < GE_ALLOW_NONE)
        {
          if (!gstate->nPrevFingers)
          {
            // 2 Finger from zero. Send one of the 2 touch positions
            // before sending the centroid
            postConvertedMotionXY(local, mt->mem.xdown, mt->mem.ydown);
            send_button(local, gs, MT_BUTTON_LEFT+1, 1);
          }
          
          /* Cancel hold timer and stop gestures other than pinch */
          DEBUG_INFO(DEBUG_X_FULL, "Canceled hold timer\n");
          gstate->holdActive = FALSE;
          gstate->distance = gs->distance;
          // Send the position
          postConvertedMotionXY(local, gs->x, gs->y);
        }
        else if (nFingers == 1 && gstate->nPrevFingers == 0 && gstate->gestureSent == GE_ALLOW_ALL)
        {
            /* We can hold in this case. Let's start the timer */
            
            gstate->holdActive = TRUE;
            DEBUG_INFO(DEBUG_X_FULL, "Can hold : %d. Starting timer\n");
            gstate->timer = TimerSet(gstate->timer, 0, mt->options.hold_time, timerFunc, local);
            // Send the position
            postConvertedMotionXY(local, gs->x, gs->y);
        }
      } 
    }
    else
    {
      DEBUG_INFO(DEBUG_X_LOW, "Touch up X: %d Y: %d (%d,%d) Delta: (%d,%d) (%ums)\n", mt->mem.xup, mt->mem.yup, GE_CONVERT_X(mt->mem.xup), GE_CONVERT_Y(mt->mem.yup), GE_CONVERT_X(mt->mem.xup - mt->mem.xdown), GE_CONVERT_Y(mt->mem.yup - mt->mem.ydown), gettimems());
      if (mt->options.debug)
      {
        DEBUG_INFO(DEBUG_LLOG, "Touch up X: %d Y: %d (%d,%d) Delta: (%d,%d) (%ums)\n", mt->mem.xup, mt->mem.yup, GE_CONVERT_X(mt->mem.xup), GE_CONVERT_Y(mt->mem.yup), GE_CONVERT_X(mt->mem.xup - mt->mem.xdown), GE_CONVERT_Y(mt->mem.yup - mt->mem.ydown), gettimems());
      }
    }
  
    if (gstate->gestureSent < GE_ALLOW_NONE)
    {
      foreach_bit(i, gs->btmask)
      {
        /* Send the button events */
        DEBUG_INFO(DEBUG_X_FULL, "Posting button event. Button : %d __ Value : %d\n", i, GETBIT(gs->btdata, i));
        send_button(local, gs, i + 1, GETBIT(gs->btdata, i));
      }
    }
  }
}

static void handle_move_events(LocalDevicePtr local,
                               const struct Gestures *gs,
                               const struct Capabilities *caps,
                               GestureState *gstate,
                               int nFingers)
{
  struct MTouch *mt = local->private;
  
  DEBUG_INFO(DEBUG_X_FULL, "Testing nFingers : %d\n", nFingers);
  if (!nFingers)
    return;

  // Don't move on 2 finger down if pinch is not allowed
  if (nFingers > 1 && gstate->gestureSent == GE_ALLOW_NONE)
    return;
	
  DEBUG_INFO(DEBUG_X_FULL, "Testing GS_MOVE\n");
  if (GETBIT(gs->type, GS_MOVE))
  {
    DEBUG_INFO(DEBUG_X_FULL, "In handle_move_events : %d\n", gstate->gestureSent);
    // Touch has moved.
    postConvertedMotionXY(local, gs->x, gs->y); 
    /* Update the HOLD timer only if we are in the initiale state */
    if (gstate->gestureSent == GE_ALLOW_ALL)
    {
      DEBUG_INFO(DEBUG_X_FULL, "In handle_move_events : %d\n", mt->mem.xdown);
      if (mt->mem.xdown)
      {
        int dx = mt->mem.xdown - gs->x;
        int dy = mt->mem.ydown - gs->y;
        int distSqr = dx*dx + dy*dy;
        int xMaxDist = (int)(mt->options.hold_fraction * get_cap_xsize(caps));
        int yMaxDist = (int)(mt->options.hold_fraction * get_cap_ysize(caps));
        int maxDistSqr = xMaxDist*xMaxDist + yMaxDist*yMaxDist;
       
        DEBUG_INFO(DEBUG_X_FULL, "DX : %d __ DY : %d __ DSQR: %d __ maxDist: %d\n", dx, dy, distSqr, maxDistSqr);
        if (distSqr > maxDistSqr)
        {
          DEBUG_INFO(DEBUG_X_FULL, "Canceling. Moved out of HOLD radius\n");
          gstate->holdActive = FALSE;
        }
      }
    }
    else
    {
      DEBUG_INFO(DEBUG_X_FULL, "ALLOW ALL NOT SET : holdActive : %d\n", gstate->holdActive);
      gstate->holdActive = FALSE;
    }
  }
}

static void handle_swipe_events(LocalDevicePtr local,
                                const struct Gestures *gs,
                                const struct Capabilities *caps,
                                GestureState *gstate,
                                int nFingers)
{
  struct MTouch *mt = local->private;
  
  if (nFingers > 1 || (!nFingers && !gstate->nPrevFingers))
    return;

  /* Send a swipe if no swipe event was previously sent */
  if (GETBIT(gs->type, GS_VSWIPE) && gstate->gestureSent == GE_ALLOW_ALL) {
    float step = mt->options.vswipe_fraction * (float)get_cap_ysize(caps);
    gstate->gestureSent = button_scroll(local, compass[mt->orientation][0]+1, compass[mt->orientation][1]+1, &gstate->vswipe, step, gs->dy);
  }
  else if (GETBIT(gs->type, GS_HSWIPE) && gstate->gestureSent == GE_ALLOW_ALL) {
    float step = mt->options.hswipe_fraction * (float)get_cap_xsize(caps);
    gstate->gestureSent = button_scroll(local, compass[mt->orientation][2]+1, compass[mt->orientation][3]+1, &gstate->hswipe, step, gs->dx);
  }
}

static void handle_scale_events(LocalDevicePtr local,
                                const struct Gestures *gs,
                                const struct Capabilities *caps,
                                GestureState *gstate,
                                int nFingers)
{
  struct MTouch *mt = local->private;
  
  if (nFingers < 2)
    return;

  if (GETBIT(gs->type, GS_SCALE) && (gstate->gestureSent < GE_ALLOW_NONE)) {
    if (gstate->distance == 0.0f)
      gstate->distance = gs->distance;
    float step = 1.0f + mt->options.scale_fraction * (float)get_cap_xsize(caps);
    //xf86PostMotionEvent(local->dev, 1, 0, 2, gs->x, gs->y);
    gstate->gestureSent = button_scale(local, gstate, MT_BUTTON_SCALE_DOWN+1, MT_BUTTON_SCALE_UP+1, &gstate->distance, step, gs->distance);
  }
}

static void handle_gestures(LocalDevicePtr local,
          const struct Gestures *gs,
          const struct Capabilities *caps)
{
  struct MTouch *mt = local->private;
  GestureState  *gstate = &mt->ge_state;

  /* Get the number of fingers currently detected */
  int nFingers = bitcount(mt->mem.fingers);

  DEBUG_INFO(DEBUG_X_FULL, "Clearing gesture state\n");
  clear_gesture_state(local, gs, gstate, nFingers);
  
  DEBUG_INFO(DEBUG_X_FULL, "Move events\n");
  handle_move_events(local, gs, caps, gstate, nFingers);
  
  DEBUG_INFO(DEBUG_X_FULL, "Button event\n");
  handle_button_events(local, gs, gstate, nFingers);

  DEBUG_INFO(DEBUG_X_FULL, "Swipe events\n");
  handle_swipe_events(local, gs, caps, gstate, nFingers);
 
  DEBUG_INFO(DEBUG_X_FULL, "Pinch events\n");
#if GE_PINCH_ENABLED == 1
  handle_scale_events(local, gs, caps, gstate, nFingers);
#endif

  DEBUG_INFO(DEBUG_X_FULL, "Setting prev fingers.. out\n");
  gstate->nPrevFingers = nFingers;
}

/* called for each full received packet from the touchpad */
static void read_input(LocalDevicePtr local)
{
  struct Gestures gs;
  struct MTouch *mt = local->private;

  while (read_packet(mt, local->fd) > 0) {
    pthread_mutex_lock(&ge_mutex);
    extract_gestures(&gs, mt);
    handle_gestures(local, &gs, &mt->caps);
    pthread_mutex_unlock(&ge_mutex);
  }
  
  if (has_delayed_gestures(mt, local->fd)) {
    extract_delayed_gestures(&gs, mt);
    handle_gestures(local, &gs, &mt->caps);
  }
}

static Bool device_control(DeviceIntPtr dev, int mode)
{
  LocalDevicePtr local = dev->public.devicePrivate;
  switch (mode) {
  case DEVICE_INIT:
    xf86Msg(X_INFO, "device control: init\n");
    return device_init(dev, local);
  case DEVICE_ON:
    xf86Msg(X_INFO, "device control: on\n");
    return device_on(local);
  case DEVICE_OFF:
    xf86Msg(X_INFO, "device control: off\n");
    return device_off(local);
  case DEVICE_CLOSE:
    xf86Msg(X_INFO, "device control: close\n");
    return device_close(local);
  default:
    xf86Msg(X_INFO, "device control: default\n");
    return BadValue;
  }
}

static void printOptions(MOptions *options)
{
  xf86Msg(X_INFO, "Option VScrollFrac : %f\n", options->vscroll_fraction);
  xf86Msg(X_INFO, "Option HScrollFrac : %f\n", options->hscroll_fraction);
  xf86Msg(X_INFO, "Option VSwipeFrac : %f\n", options->vswipe_fraction);
  xf86Msg(X_INFO, "Option HSwipeFrac : %f\n", options->hswipe_fraction);
  xf86Msg(X_INFO, "Option ScaleFrac : %f\n", options->scale_fraction);
  xf86Msg(X_INFO, "Option RotFrac : %f\n", options->rot_fraction);
  xf86Msg(X_INFO, "Option HoldTime : %d\n", options->hold_time);
  xf86Msg(X_INFO, "Option HoldFrac : %f\n", options->hold_fraction);
  xf86Msg(X_INFO, "Option VSwipeAngle : %d\n", options->vswipe_angle);
  xf86Msg(X_INFO, "Option Debug : %d\n", options->debug);
}

static InputInfoPtr preinit(InputDriverPtr drv, IDevPtr dev, int flags)
{
  struct MTouch *mt;
  InputInfoPtr local = xf86AllocateInput(drv, 0);
  if (!local)
    goto error;
  mt = xcalloc(1, sizeof(struct MTouch));
  if (!mt)
    goto error;

  local->name = dev->identifier;
  local->type_name = XI_TOUCHPAD;
  local->device_control = device_control;
  local->read_input = read_input;
  local->private = mt;
  local->flags = XI86_POINTER_CAPABLE | XI86_SEND_DRAG_EVENTS | XI86_KEYBOARD_CAPABLE;
  local->conf_idev = dev;

  if (pthread_mutex_init(&ge_mutex, NULL))
    goto error;
  
  mt->options.vscroll_fraction = xf86SetRealOption(dev->commonOptions,
                                                   "VScrollFrac",
                                                   DEF_VSCROLL_FRAC);
  mt->options.hscroll_fraction = xf86SetRealOption(dev->commonOptions,
                                                   "HScrollFrac",
                                                   DEF_HSCROLL_FRAC);
  mt->options.vswipe_fraction = xf86SetRealOption(dev->commonOptions,
                                                   "VSwipeFrac",
                                                   DEF_VSWIPE_FRAC);
  mt->options.hswipe_fraction = xf86SetRealOption(dev->commonOptions,
                                                   "HSwipeFrac",
                                                   DEF_HSWIPE_FRAC);
  mt->options.scale_fraction = xf86SetRealOption(dev->commonOptions,
                                                   "ScaleFrac",
                                                   DEF_SCALE_FRAC);
  mt->options.rot_fraction = xf86SetRealOption(dev->commonOptions,
                                                   "RotateFrac",
                                                   DEF_ROT_FRAC);
  mt->options.hold_time = xf86SetIntOption(dev->commonOptions,
                                                  "HoldTime",
                                                   DEF_HOLD_TIME);
  mt->options.hold_fraction = xf86SetRealOption(dev->commonOptions,
                                                  "HoldFrac",
                                                   DEF_HOLD_FRAC);
  mt->options.vswipe_angle = xf86SetIntOption(dev->commonOptions,
                                                  "VSwipeAngle",
                                                   DEF_VSWIPE_ANGLE);
  mt->options.randr = xf86SetBoolOption(dev->commonOptions,
                                        "RandR",
                                        DEF_RANDR_OPT);
  mt->options.screenshot = xf86SetBoolOption(dev->commonOptions,
                                             "ScreenShot",
                                             DEF_SCREENSHOT_OPT);
  mt->options.debug = xf86SetBoolOption(dev->commonOptions,
                                             "Debug",
                                             DEF_DEBUG_OPT);
  printOptions(&mt->options);

  xf86CollectInputOptions(local, NULL, NULL);
  /* xf86OptionListReport(local->options); */
  xf86ProcessCommonOptions(local, local->options);

  local->flags |= XI86_CONFIGURED;
 error:
  return local;
}

static void uninit(InputDriverPtr drv, InputInfoPtr local, int flags)
{
  xfree(local->private);
  local->private = 0;
  xf86DeleteInput(local, 0);
  pthread_mutex_destroy(&ge_mutex);
}

static InputDriverRec MULTITOUCH = {
  1,
  "multitouch",
  NULL,
  preinit,
  uninit,
  NULL,
  0
};

static XF86ModuleVersionInfo VERSION = {
  "multitouch",
  MODULEVENDORSTRING,
  MODINFOSTRING1,
  MODINFOSTRING2,
  XORG_VERSION_CURRENT,
  0, 1, 0,
  ABI_CLASS_XINPUT,
  ABI_XINPUT_VERSION,
  MOD_CLASS_XINPUT,
  {0, 0, 0, 0}
};

static pointer setup(pointer module, pointer options, int *errmaj, int *errmin)
{
  xf86AddInputDriver(&MULTITOUCH, module, 0);
  return module;
}

XF86ModuleData multitouchModuleData = {&VERSION, &setup, NULL };
