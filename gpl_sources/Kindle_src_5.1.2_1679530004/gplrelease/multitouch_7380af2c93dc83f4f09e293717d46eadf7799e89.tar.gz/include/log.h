/*
 * Copyright 2011 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 */

#ifndef LAB126UTILS_LOG_H_INCLUDED_
#define LAB126UTILS_LOG_H_INCLUDED_

#define LLOG_SUBCOMP "GestureEngine"
#define LLOG_G_LOG_MASK gestureengine_g_llog_mask

#include <llog.h>

#define DEBUG_NONE     0
#define DEBUG_LLOG     1 << 0 
#define DEBUG_X_LOW    1 << 1
#define DEBUG_X_MEDIUM 1 << 2
#define DEBUG_X_FULL   1 << 3

// Change this to set maximum allowed debug level
#define DEBUG_LEVEL DEBUG_LLOG

// For debug purposes only
#define ZF_OUTPUT_X_DIM               4096
#define ZF_OUTPUT_Y_DIM               4096
#define EINK_DEF_X_DIM                600
#define EINK_DEF_Y_DIM                800
#define GE_CONVERT_X(x) (((x) * EINK_DEF_X_DIM) / ZF_OUTPUT_X_DIM)
#define GE_CONVERT_Y(y) (((y) * EINK_DEF_Y_DIM) / ZF_OUTPUT_Y_DIM)

#define GE_LLOG_ERROR(str_error_id, err_args_format, err_msg_format, ...)  LLOGS_ERROR(LLOG_SUBCOMP, str_error_id, err_args_format, err_msg_format, ##__VA_ARGS__ )
#define GE_LLOG_WARN(str_error_id, err_args_format, err_msg_format, ...)   LLOGS_WARN(LLOG_SUBCOMP, str_error_id, err_args_format, err_msg_format, ##__VA_ARGS__ )

#if DEBUG_LEVEL > 0
#define DEBUG_INFO(level, fmt, args...) \
 if ((level) & DEBUG_LLOG) \
 { \
   GE_LLOG_WARN("Touch", "", fmt, ## args); \
 } \
else if (((level) & ~DEBUG_LLOG) <= (DEBUG_LEVEL & ~DEBUG_LLOG)) \
 { \
   xf86Msg(X_INFO, "[GestureEngine] " fmt, ## args); \
 }
#else
  #define DEBUG_INFO(level, fmt, args...) //NOP
#endif

unsigned int gettimems();

#endif // LAB126UTILS_LOG_H_INCLUDED_
