/***************************************************************************
 *
 * Multitouch X driver
 * Copyright (C) 2008 Henrik Rydberg <rydberg@euromail.se>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 **************************************************************************/

#ifndef MTOUCH_H
#define MTOUCH_H

#include "memory.h"
#include "mtdev-iobuf.h"

#define DEF_VSCROLL_FRAC 0.05
#define DEF_HSCROLL_FRAC 0.05
#define DEF_VSWIPE_FRAC  0.075
#define DEF_HSWIPE_FRAC  0.10
#define DEF_SCALE_FRAC   0.05
#define DEF_ROT_FRAC     0.05
#define DEF_HOLD_TIME    500
#define DEF_HOLD_FRAC    0.02
#define DEF_VSWIPE_ANGLE 30
#define DEF_RANDR_OPT    FALSE 
#define DEF_SCREENSHOT_OPT   FALSE 
#define DEF_DEBUG_OPT FALSE

typedef enum
{
  PORTRAIT_UP,
  PORTRAIT_DOWN,
  PORTRAIT_LEFT,
  PORTRAIT_RIGHT
} Orientation;

typedef struct MOptions_s
{
  float vscroll_fraction;
  float hscroll_fraction;
  float vswipe_fraction;
  float hswipe_fraction;
  float scale_fraction;
  float rot_fraction;
  int   hold_time;
  float hold_fraction;
  int   vswipe_angle;
  Bool	screenshot;
  Bool  randr;
  Bool	debug;
} MOptions;

typedef struct GestureState_s
{
  int vscroll;
  int hscroll;
  float vswipe;
  float hswipe;
  int scale;
  int rot;
  float distance;
  int nPrevFingers;
  int gestureSent;
  OsTimerPtr timer;
  Bool holdActive;
} GestureState;

struct MTouch {
  struct Capabilities caps;
  struct MTDev dev;
  struct IOBuffer buf;
  struct HWState hs;
  struct MTState prev_state, state;
  struct Memory mem;
  Orientation orientation;
  GestureState ge_state;
  MOptions  options; 
};

int configure_mtouch(struct MTouch *mt, int fd);
int open_mtouch(struct MTouch *mt, int fd);
int get_mtouch(struct MTouch *mt, int fd, struct input_event* ev, int ev_max);
int close_mtouch(struct MTouch *mt, int fd);

int parse_event(struct MTouch *mt, const struct input_event *ev);

int has_delayed_gestures(struct MTouch *mt, int fd);

static inline void mt_delay_movement(struct MTouch *mt, int t)
{
  mem_hold_movement(&mt->mem, mt->state.evtime + t);
}

static inline void mt_skip_movement(struct MTouch *mt, int t)
{
  mem_forget_movement(&mt->mem, mt->state.evtime + t);
}

#endif
