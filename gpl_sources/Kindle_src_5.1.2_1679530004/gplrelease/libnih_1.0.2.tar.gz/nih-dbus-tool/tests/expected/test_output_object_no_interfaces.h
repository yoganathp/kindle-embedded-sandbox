/* test
 *
 * Copyright (C) 2009 Joe Bloggs.
 *
 * This file was automatically generated; see the source for copying
 * conditions.
 */

#ifndef TEST_TEST_H
#define TEST_TEST_H

#include <dbus/dbus.h>

#include <stdint.h>

#include <nih/macros.h>

#include <nih-dbus/dbus_interface.h>
#include <nih-dbus/dbus_message.h>


NIH_BEGIN_EXTERN

extern const NihDBusInterface *my_interfaces[];

NIH_END_EXTERN

#endif /* TEST_TEST_H */
