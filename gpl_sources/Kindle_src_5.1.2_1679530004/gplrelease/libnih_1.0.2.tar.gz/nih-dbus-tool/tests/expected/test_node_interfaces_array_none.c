const NihDBusInterface *my_interfaces[] = {
	NULL
};
